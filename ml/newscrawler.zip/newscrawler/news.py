from ipywidgets import widgets
from ipywidgets import *
from traitlets import *
from IPython.display import display, Markdown

#converting unicode to string
import unicodedata

#NewsApiClient to find URLs of news
from newsapi import NewsApiClient

# Requests is used to get a html markup from a URL
import requests

# Beautiful Soup for crawling and capturing text
from bs4 import BeautifulSoup
newsapi = NewsApiClient(api_key='179a37ab48714d788edbe5c1a4ed6fda')

all_articles = newsapi.get_everything(q = 'Modi',
                                      language='en',
                                      sources='CNN',
                                      sort_by = 'relevancy',
                                      page_size = 10)

sources = newsapi.get_sources()

list_url = []
for item in all_articles['articles']:
    list_url.append(unicodedata.normalize('NFKD', item['url']).encode('ascii','ignore'))
display(list_url)

article_content = []
for i in list_url:
    page = requests.get(i)
    soup = BeautifulSoup(page.content, 'html.parser')
    content = soup.find_all(['p'])
    for line in content:
        line_string = unicodedata.normalize('NFKD', line.get_text()).encode('ascii','ignore')
        if (len(line_string)>20):
            article_content.append(line_string)
    article_content.append(',')
    
    
    
    counter = 1
display(Markdown("# Article " + str(counter)))
for line in article_content:
    if(line == ','):
        counter = counter + 1
        if (not(counter<=10)):
            break;
        display(Markdown("# Article " + str(counter)))
        continue
    display(line)

